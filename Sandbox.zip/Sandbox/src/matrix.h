#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>

#ifndef MATRIX_H
#define MATRIX_H

typedef struct {
    float*     values;
    uint32_t   rows;
    uint32_t   cols;
} Matrix;

static inline Matrix mat_new(uint32_t rows, uint32_t cols) {
    uint32_t count = rows * cols;
    return (Matrix){
        .rows   = rows,
        .cols   = cols,
        .values = (count == 0 ? NULL : calloc(count, sizeof(float))),
    };
}

static inline void mat_assert_values(const Matrix* restrict m) {
    assert(m);
    assert(m->values);
    (void)m;
}

static inline void mat_free(Matrix* restrict m) {
    assert(m);

    if (m->values) free(m->values);

    m->rows   = 0;
    m->cols   = 0;
    m->values = NULL;
}

static inline uint32_t mat_index(uint32_t row, uint32_t col, uint32_t rows) {
    return (row) + (col * rows); // Column-major!
}

static inline float* mat_at(Matrix* restrict m, uint32_t row, uint32_t col) {
    assert(row < m->rows);
    assert(col < m->cols);
    return &m->values[mat_index(row, col, m->rows)];
}

static inline float mat_at_const(const Matrix* restrict m, uint32_t row, uint32_t col) {
    assert(row < m->rows);
    assert(col < m->cols);
    return m->values[mat_index(row, col, m->rows)];
}

static inline bool mat_same_shape(const Matrix* restrict m1, const Matrix* restrict m2) {
    return (m1->rows == m2->rows && m1->cols == m2->cols);
}

static inline void mat_ensure_shape(Matrix* restrict m, uint32_t rows, uint32_t cols) {
    assert(m);

    if (m->rows != rows || m->cols != cols) {
        mat_free(m);
        *m = mat_new(rows, cols);
    }
}

static inline void mat_zero(Matrix* restrict m) {
    mat_assert_values(m);
    memset(m->values, 0x00, m->rows * m->cols * sizeof(float));
}

static inline void mat_copy_into(const Matrix* restrict src, Matrix* restrict dest) {
    mat_assert_values(src);
    assert(dest);
    
    mat_ensure_shape(dest, src->rows, src->cols);
    memcpy(dest->values, src->values, src->rows * src->cols * sizeof(float));
}

static inline void mat_move_into(Matrix* restrict src, Matrix* restrict dest) {
    mat_assert_values(src);
    assert(dest);
    
    mat_free(dest);
    *dest = *src;

    src->rows   = 0;
    src->cols   = 0;
    src->values = NULL;
}


static inline void mat_kaiming_init(Matrix* restrict m, uint32_t fan_in, float leakage) {
    float range = sqrtf(6.0f / ((1.0f + leakage*leakage) * (float)fan_in));
    
    for (uint32_t i = 0; i < m->rows * m->cols; ++i)
        m->values[i] = ((float)rand() / (float)RAND_MAX * 2.0f - 1.0f) * range;
}

static inline void mat_add_into(const Matrix* restrict src, Matrix* restrict dest) {
    mat_assert_values(src);
    mat_assert_values(dest);
    assert(mat_same_shape(src, dest));

    for (uint32_t i = 0; i < src->rows * src->cols; ++i)
        dest->values[i] += src->values[i];
}

static inline void mat_sub_into(const Matrix* restrict src, Matrix* restrict dest) {
    mat_assert_values(src);
    mat_assert_values(dest);
    assert(mat_same_shape(src, dest));

    for (uint32_t i = 0; i < src->rows * src->cols; ++i)
        dest->values[i] -= src->values[i];
}

static inline void mat_component_product(const Matrix* m1, const Matrix* m2, Matrix* dest) {
    mat_assert_values(m1);
    mat_assert_values(m2);
    assert(mat_same_shape(m1, m2));
    assert(dest);

    mat_ensure_shape(dest, m1->rows, m1->cols);

    for (uint32_t i = 0; i < m1->rows * m1->cols; ++i) {
        dest->values[i] = m1->values[i] * m2->values[i];
    }
}

static inline void mat_func_into(const Matrix* src, float(*Function)(float), Matrix* dest) {
    mat_assert_values(src);
    assert(Function);
    assert(dest);

    mat_ensure_shape(dest, src->rows, src->cols);

    for (uint32_t i = 0; i < src->rows * src->cols; ++i)
        dest->values[i] = Function(src->values[i]);
}

static inline float mat_mse(const Matrix* restrict output, const Matrix* restrict desired_output) {
    mat_assert_values(output);
    mat_assert_values(desired_output);
    assert(mat_same_shape(output, desired_output));

    float sum = 0.0f;

    for (uint32_t i = 0; i < output->rows * output->cols; ++i) {
        float val = (output->values[i] - desired_output->values[i]);
        sum += val * val;
    }

    return sum;
}

static inline void mat_mse_derivatives(const Matrix* restrict output, const Matrix* restrict desired_output, Matrix* restrict dest) {
    mat_assert_values(output);
    mat_assert_values(desired_output);
    assert(mat_same_shape(output, desired_output));
    assert(dest);

    mat_ensure_shape(dest, output->rows, output->cols);
    mat_zero(dest);

    for (uint32_t i = 0; i < output->rows * output->cols; ++i)
        dest->values[i] = output->values[i] - desired_output->values[i];
}

static inline void mat_transpose_into(const Matrix* restrict m, Matrix* restrict dest) {
    mat_assert_values(m);
    assert(dest);

    mat_ensure_shape(dest, m->cols, m->rows);

    for (uint32_t i = 0; i < m->rows; ++i)
        for (uint32_t j = 0; j < m->cols; ++j)
            *mat_at(dest, j, i) = mat_at_const(m, i, j);
}

static inline void mat_mul_into(const Matrix* restrict m1, const Matrix* restrict m2, Matrix* restrict dest) {
    mat_assert_values(m1);
    mat_assert_values(m2);
    assert(dest);

    assert(m1->cols == m2->rows);

    mat_ensure_shape(dest, m1->rows, m2->cols);
    
    for (uint32_t k = 0; k < m1->cols; ++k) {
        for (uint32_t j = 0; j < m2->cols; ++j) {
            const float b = mat_at_const(m2, k, j);
    
            for (uint32_t i = 0; i < m1->rows; ++i) {
                *mat_at(dest, i, j) += mat_at_const(m1, i, k) * b;
            }
        }
    }
}

// static inline void mat_mul(const Matrix* a, const Matrix* b, Matrix* out, bool transpose_a, bool transpose_b, bool override_out) {
//     mat_assert_values(a);
//     mat_assert_values(b);
//     assert(out);
// 
//     uint32_t a_rows = (transpose_a ? a->cols : a->rows);
//     uint32_t a_cols = (transpose_a ? a->rows : a->cols);
// 
//     uint32_t b_rows = (transpose_b ? b->cols : b->rows);
//     uint32_t b_cols = (transpose_b ? b->rows : b->cols);
// 
//     assert(a_cols == b_rows);
// 
//     mat_ensure_shape(out, a_cols, b_rows);
//     if (override_out) mat_zero(out);
// 
//     for (uint32_t i = 0; i < a_rows; ++i) {
//         for (uint32_t k = 0; k < b_cols; ++k) {
//             float* dest = mat_at(out, i, k);
// 
//             for (uint32_t j = 0; j < a_cols; ++j) {
//                 *dest +=
//                     mat_at_const(a, ) *
//                     mat_at_const(b, );
//             }
//         }
//     }
// }

static inline void mat_mul_transposed_into(const Matrix* restrict m1_T, const Matrix* restrict m2, Matrix* restrict dest) {
    mat_assert_values(m1_T);
    mat_assert_values(m2);
    assert(dest);

    assert(m1_T->rows == m2->rows);

    mat_ensure_shape(dest, m1_T->cols, m2->cols);
    
    for (uint32_t k = 0; k < m1_T->rows; ++k) {
        for (uint32_t j = 0; j < m2->cols; ++j) {
            const float b = mat_at_const(m2, k, j);
    
            for (uint32_t i = 0; i < m1_T->cols; ++i) {
                *mat_at(dest, i, j) += mat_at_const(m1_T, k, i) * b;
            }
        }
    }
}


#endif