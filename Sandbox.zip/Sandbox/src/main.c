#include <stdio.h>
#include <stdint.h>

typedef struct {
    float r, i;
} Complex;

Complex cmplx(float r, float i) {
    return (Complex){
        .r = r,
        .i = i,
    };
}

Complex cmplx_mul_f(Complex c, float f) {
    return (Complex){
        .r = c.r * f,
        .i = c.i * f,
    };
}

Complex cmplx_sqr(Complex c) {
    return (Complex){
        .r = c.r*c.r - c.i*c.i,
        .i = 2.0f * c.r * c.i,
    };
}

Complex cmplx_add(Complex a, Complex b) {
    return (Complex){
        .r = a.r + b.r,
        .i = a.i + b.i,
    };
}

float cmplx_abs_sqr(Complex c) {
    return (c.r*c.r + c.i*c.i);
}

float lerp(float p, float from, float to) {
    return from + (to - from) * p;
}

float invlerp(float x, float from, float to) {
    return (x - from) / (to - from);
}

float map(float x, float fromMin, float fromMax, float toMin, float toMax) {
    float p = invlerp(x, fromMin, fromMax);
    return lerp(p, toMin, toMax);
}


int main(void) {
    const char* filePath = "./output.ppm";
    FILE* f = fopen(filePath, "wb");

    int w = 8000;
    int h = 4000;

    fprintf(f, "P6\n");
    fprintf(f, "%d %d\n", w, h);
    fprintf(f, "255\n");

    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            Complex c = cmplx(-0.9f, 0.2f);
            Complex z = cmplx(
                map(x, 0, w-1, -2, 2),
                map(y, 0, h-1, -1, 1)
            );
            // Complex z = cmplx(
            //     map(x, 0, w-1, -3, 1),
            //     map(y, 0, h-1, -1, 1)
            // );

            uint8_t i = 0;

            for (; i < 255; ++i) {
                // z -> z^2 + c
                z = cmplx_add(cmplx_sqr(z), c);
                if (cmplx_abs_sqr(z) >= 4.0f) break;
            }
            
            fputc(i, f); // Red
            fputc(i, f); // Green
            fputc(i, f); // Blue
        }
    }

    fclose(f);
    printf("Output file: %s\n", filePath);
    return 0;
}