#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <pthread.h>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#define NUM_THREADS      4
#define MSAA             4
#define MAX_ITER       256
#define WIDTH         4000
#define HEIGHT        2000

typedef struct {
    float r, i;
} Complex;

Complex cmplx(float r, float i) {
    return (Complex){.r = r, .i = i};
}

Complex cmplx_sqr(Complex c) {
    return (Complex){
        .r = c.r*c.r - c.i*c.i,
        .i = 2.0f * c.r * c.i
    };
}

Complex cmplx_add(Complex a, Complex b) {
    return (Complex){.r = a.r + b.r, .i = a.i + b.i};
}

float cmplx_abs_sqr(Complex c) {
    return c.r*c.r + c.i*c.i;
}

float map(float x, float a, float b, float c, float d) {
    return c + (x - a) * (d - c) / (b - a);
}

uint32_t mandelbrot_iter(Complex c, uint32_t max_iter) {
    Complex z = {0};
    uint32_t i = 0;

    for (; i < max_iter; ++i) {
        z = cmplx_add(cmplx_sqr(z), c); // z = z^2 + c
        if (cmplx_abs_sqr(z) >= 4.0f) return i;
    }

    return 0;
}

void shader(float x, float y, float pixel_size, uint8_t* rgb) {
    Complex c = cmplx(map(x, 0, 1, -2.5f, 1.5f), map(y, 0, 1, -1, 1));
    Complex z = {0};

    uint32_t avg = 0;

    for (uint32_t i = 0; i < MSAA; ++i)
    for (uint32_t j = 0; j < MSAA; ++j)
        avg += mandelbrot_iter(cmplx_add(c, cmplx(pixel_size * (float)i / (float)MSAA, pixel_size * (float)j / (float)MSAA)), MAX_ITER);

    avg = avg / (MSAA * MSAA);

    rgb[0] = map(avg, 0, MAX_ITER-1, 0.0f, 255.0f);
    rgb[1] = 0x00;
    rgb[2] = 0x00;
}

typedef struct {
    uint32_t start_x;
    uint32_t end_x;
    uint32_t start_y;
    uint32_t end_y;
    uint32_t w, h;
    uint8_t* buffer;
    uint32_t index;
} BufferArg;

void* shader_worker(void* arg) {
    BufferArg* ctx = arg;

    for (uint32_t y = ctx->start_y; y < ctx->end_y; ++y)
        for (uint32_t x = ctx->start_x; x < ctx->end_x; ++x)
            shader((float)x / (float)ctx->w, (float)y / (float)ctx->h, 1.0f / (float)ctx->w, &ctx->buffer[(x + y * ctx->w) * 3]);

    printf("Worker %d done!\n", ctx->index);

    return NULL;
}

int main(void) {
    const char* filePath = "./output.png";

    uint32_t w = WIDTH;
    uint32_t h = HEIGHT;

    uint8_t* buffer = calloc(w * h * 3, sizeof(uint8_t));

    pthread_t threads[NUM_THREADS] = {0};
    BufferArg args   [NUM_THREADS] = {0};

    for (uint32_t i = 0; i < NUM_THREADS; ++i)
        args[i] = (BufferArg){
            .buffer = buffer,
            .w = w,
            .h = h,
            .index   = i,
            .start_x = 0,
            .end_x   = w,
            .start_y = (i + 0) * h / NUM_THREADS,
            .end_y   = (i + 1) * h / NUM_THREADS,
        };

    for (uint32_t i = 0; i < NUM_THREADS; ++i)
        pthread_create(&threads[i], NULL, shader_worker, &args[i]);

    for (uint32_t i = 0; i < NUM_THREADS; ++i)
        pthread_join(threads[i], NULL);

    stbi_write_png(filePath, w, h, 3, buffer, w * 3);

    free(buffer);
    printf("Written to: %s\n", filePath);

    return 0;
}
